#!/usr/bin/env python3

# Import necessary Python modules and AWS Boto3 library.
import boto3
import json
from operator import itemgetter
import string 
import random
import time 
import webbrowser 
import requests  
from botocore.exceptions import ClientError
import subprocess 

#Naming function for uniqueness
def name():
    suffix = ''.join(random.choice(string.ascii_lowercase + string.digits) for i in range (6))
    return suffix 

#Global variables for the script.
security_group_name = 'WebServer-' + name()
bucket_name = name() + '-dsinnott'

# Initialize Boto3 resources and clients for EC2 and S3.
ec2_resource = boto3.resource('ec2')
ec2_client = boto3.client('ec2')

s3 = boto3.resource("s3")
s3_client = boto3.client("s3")



# Describe available VPCs and get the first VPC's ID 
response = ec2_client.describe_vpcs()
vpc_id = response.get('Vpcs', [{}])[0].get('VpcId','')

# Function to create a security group.
def security_group_create():

    # Create a security group with a name, description, and associated VPC.
    try:
	        security_group = ec2_client.create_security_group(
		    Description='Web Server traffic rules',
		    GroupName= security_group_name,
		    VpcId= vpc_id)

            # Get the ID of the newly created security group.
	        security_group_id = security_group['GroupId']
	        print ('Security Group: %s created in VPC: %s.' % (security_group_name, vpc_id))

            # Authorize inbound traffic rules for the security group
	        ec2_client.authorize_security_group_ingress(
		        GroupId =security_group_id,
		        IpPermissions=[
			     {'IpProtocol': 'tcp',
		 	        'FromPort': 80,
		 	        'ToPort': 80,
		 	        'IpRanges': [{'CidrIp': '0.0.0.0/0'}]}, # Allowing HTTP (Port 80) traffic from anywhere.
			        {'IpProtocol': 'tcp',
		 	        'FromPort': 22,
		 	        'ToPort' : 22,
		 	        'IpRanges': [{'CidrIp': '0.0.0.0/0'}]} # Allowing SSH (Port 22) traffic from anywhere.
])

    except ClientError as e:
	    print(e)


#User data 	
data = """ #!/bin/bash
            sudo yum update -y
			yum install httpd -y 
			systemctl enable httpd
			systemctl start httpd  
			echo '<html>' > index.html
			echo '<br>Instance ID: ' >> index.html
			curl http://169.254.169.254/latest/meta-data/instance-id >> index.html
			echo '<br>Instance Type: ' >> index.html
			curl http://169.254.169.254/latest/meta-data/instance-type >> index.html
			echo '<br>Availability Zone: ' >> index.html 
			curl http://169.254.169.254/latest/meta-data/placement/availability-zone>> index.html
			echo '<br>Private IP address: ' >> index.html
			curl http://169.254.169.254/latest/meta-data/local-ipv4 >> index.html
            echo '</html>' >> index.html
			cp index.html /var/www/html/index.html
  			"""



#Function to create an EC2 instance
def create_ec2():

    # Try to fetch latest image_id from AWS for AWS Linux 2 
    # https://stackoverflow.com/questions/51611411/get-latest-ami-id-for-aws-instance
    filters = [ {
        'Name': 'name',
        'Values': ['amzn2-ami-kernel*']
    } ]
    # Describe images based on the specified filters and AWS image owners.
    response = ec2_client.describe_images(
        Filters=filters,
        Owners=[
        'amazon'
        ]
    )
    # Sort the images by creation date in reverse order to get the latest one.
    image_details = sorted(response['Images'],key=itemgetter('CreationDate'),reverse=True)
    latest_image_id = image_details[0]['ImageId']
    

    # Create a new EC2 instance using the latest image.
    try:
        new_instance = ec2_resource.create_instances (
            ImageId=latest_image_id,
            MinCount=1,
            MaxCount=1,
            InstanceType='t2.nano',
            UserData=data,
            SecurityGroupIds=[security_group_name],
            KeyName='assignment_key',  # Specify the SSH key pair name.
            TagSpecifications=[
                {
                    'ResourceType': 'instance',
                    'Tags': [{'Key': 'Name', 'Value': 'Web Server'}]
                }
            ]
        )
        # Wait until the new instance is in the running state.
        new_instance[0].wait_until_running()
        new_instance[0].reload()

        

        print('Waiting for status checks to complete...')
        #Check the staus of the EC2 instance 
        while True:
            status = ec2_resource.meta.client.describe_instance_status(
                InstanceIds=[new_instance[0].id]
            )
            instance_status = status['InstanceStatuses'][0]['InstanceStatus']['Status']
            system_status = status['InstanceStatuses'][0]['SystemStatus']['Status']
    
            if instance_status == 'ok' and system_status == 'ok':
                break

            time.sleep(20)  # Wait for 20 seconds before checking again

        #Call the monitor function 
        monitor(new_instance[0].public_ip_address)

        # Print instance details once it's running 
        print('Instance is running')
        print('Instance ID:', new_instance[0].id)
        print(f'AMI ID selected: {latest_image_id}')
        print('Public IPv4 address:', new_instance[0].public_ip_address)
        print('Public DNS name:', new_instance[0].public_dns_name)

        # Create a file containing the instance's public DNS name and open it in a web browser. 
        # https://www.geeksforgeeks.org/writing-to-file-in-python/
        meta_data = new_instance[0].public_dns_name
        with open('dsinnott-websites.txt','a') as file:
            file.write(f'http://{meta_data}\n')
        webbrowser.open_new_tab(f'http://{meta_data}')

    except Exception as e:
        print(f'Error creating EC2 instance: {str(e)}/n Existing from script....')
        exit()

    


# Function to create a S3 bucket.
def bucket_create():
    
    s3.create_bucket(Bucket=bucket_name)

    # Define a bucket policy to allow public read access to objects in the bucket
    bucket_policy = {
                "Version": "2012-10-17",
                "Statement": [
                {
                    "Sid": "PublicReadGetObject",
                    "Effect": "Allow",
                    "Principal": "*",
                    "Action": ["s3:GetObject"],
                    "Resource": f"arn:aws:s3:::{bucket_name}/*"
                }
                ]
}
    # Delete any existing public access block on the bucket.
    s3_client.delete_public_access_block(Bucket=bucket_name)
    # Apply the defined bucket policy to allow public read access  
    s3.Bucket(bucket_name).Policy().put(Policy=json.dumps(bucket_policy))


    print('Bucket Name: ' + bucket_name)

    # Download an object (e.g., 'logo.jpg') from a remote URL and upload it to the S3 bucket
    response = requests.get('http://devops.witdemo.net/logo.jpg')
    #print(response.status_code)
    #Write the object
    s3_client.put_object(Bucket=bucket_name, Key='logo.jpg',Body=response.content)



    # Define the website configuration for the S3 bucket.
    website_configuration = {
        'ErrorDocument': {'Key': 'error.html'},
        'IndexDocument': {'Suffix': 'index.html'},
    }

    # Configure the S3 bucket as a static website.
    bucket_website = s3.BucketWebsite(bucket_name)
    response = bucket_website.put(WebsiteConfiguration=website_configuration)

    # Create the HTML content for the index page.
    hmtl_content= """ <!DOCTYPE html>
                      <html>
                      <head>
                        <title>S3 website</title> 
                      </head> 
                      <body>
                      <h1> My Website </h1> 
                        <img src="logo.jpg"> 
                        </body>     
                        </html>"""
    
    # Upload the HTML content as 'index.html' to the S3 bucket
    s3_client.put_object(Body=hmtl_content, Bucket=bucket_name, Key='index.html', ContentType='text/html')

    # Generate the URL for the S3 static website. 
    s3_url = f'http://{bucket_name}.s3-website-us-east-1.amazonaws.com'
    webbrowser.open_new_tab(s3_url)

    #response = subprocess.run(f'echo -s {s3_url}\n >> dsinnott-websites.txt', shell=True)

    # Append the S3 website URL to a text file. 
    # https://www.geeksforgeeks.org/writing-to-file-in-python/
    with open('dsinnott-websites.txt','a') as file:
        file.write(f'{s3_url}\n')
    print(s3_url)


#Function to copy a monitoring script to an EC2 instance using SCP 
def monitor(instance_ip):
    response = subprocess.run(f'scp -o StrictHostKeyChecking=no -i assignment_key.pem monitoring.sh ec2-user@{instance_ip}:.', shell=True)
    if response.returncode != 0:
        print('FAILED TO COPY FILE')

    # Execute the monitoring script on the EC2 instance using SSH. 
    ssh_response = subprocess.run(f'ssh -o StrictHostKeyChecking=no -i assignment_key.pem ec2-user@{instance_ip} ./monitoring.sh', shell=True)



# Function order of execution 
name()
bucket_create()
print('-------------------------------')
security_group_create()
create_ec2()
print('-------------------------------')

